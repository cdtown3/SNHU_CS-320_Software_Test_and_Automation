/*
 * Program: Contact Service JUnit Tests
 * Author: Drew Townsend
 * Date: 05/23/21
 * Desc: JUnit Tests that are testing the Contact class
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactTest {

	// Testing class and entered params
	@Test
	void testContactClass() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");
		assertTrue(contact.getContactID().equals("56152"));
		assertTrue(contact.getFirstName().equals("Drew"));
		assertTrue(contact.getLastName().equals("Test"));
		assertTrue(contact.getPhone().equals("5555455545"));
		assertTrue(contact.getAddress().equals("123 Test St"));
	}
	
	// Should return error because ID is too long
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56125152155", "Drew", "Test", "5555455545", "123 Test St");
		});
	}
	
	// Should return error because ID is null
	@Test
	void testContactIDNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "Drew", "Test", "5555455545", "123 Test St");
		});
	}
	
	// Should return error because first name is too long
	@Test
	void testContactFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "DrewDrewDrew", "Test", "5555455545", "123 Test St");
		});
	}
	
	// Should return error because first name is null
	@Test
	void testContactFirstNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", null, "Test", "5555455545", "123 Test St");
		});
	}
	
	// Should return error because last name is too long
	@Test
	void testContactLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "TestTestTest", "5555455545", "123 Test St");
		});
	}
	
	// Should return error because last name is null
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", null, "5555455545", "123 Test St");
		});
	}
	
	// Should return error because phone num is too long
	@Test
	void testContactPhoneTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "Test", "55554555455", "123 Test St");
		});
	}
	
	// Should return error because phone num is too short
	@Test
	void testContactPhoneTooShort() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "Test", "555545545", "123 Test St");
		});
	}
	
	// Should return error because phone num is null
	@Test
	void testContactPhoneNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "Test", null, "123 Test St");
		});
	}
	
	// Should return error because address is too long
	@Test
	void testContactAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "Test", "5555455545", "123456789123456789123456789123456789");
		});
	}
	
	// Should return error because address is too null
	@Test
	void testContactAddressNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("56152", "Drew", "Test", "5555455545", null);
		});
	}

}
