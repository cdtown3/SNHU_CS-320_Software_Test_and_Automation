/*
 * Program: Contact Service JUnit Tests
 * Author: Drew Townsend
 * Date: 05/23/21
 * Desc: JUnit Tests that are testing the ContactService class
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class ContactServiceTest {

	// Testing general ContactService class
	@Test
	void testContactServiceClass() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		
		service.addContact(contact);
		assertTrue(service.contactList.get(0).getContactID() == "56152");
		assertTrue(service.contactList.get(0).getFirstName() == "Drew");
		assertTrue(service.contactList.get(0).getLastName() == "Test");
		assertTrue(service.contactList.get(0).getPhone() == "5555455545");
		assertTrue(service.contactList.get(0).getAddress() == "123 Test St");
	}
	
	// Testing that contact is added then deleted
	@Test
	void testContactServiceDeletedContact() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		service.addContact(contact);
		assertTrue(service.contactList.size() == 1);
		service.deleteContact("56152");
		assertTrue(service.contactList.size() == 0);
	}
	
	// Testing that first name was updated
	@Test
	void testContactServiceUpdateContactFirst() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		service.addContact(contact);
		service.updateContact("56152", 1, "DrewTest");
		assertTrue(service.contactList.get(0).getFirstName().equals("DrewTest"));
	}
	
	// Testing that last name was updated
	@Test
	void testContactServiceUpdateContactLast() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		service.addContact(contact);
		service.updateContact("56152", 2, "TestTest");
		assertTrue(service.contactList.get(0).getLastName().equals("TestTest"));
	}
	
	// Testing that phone num was updated
	@Test
	void testContactServiceUpdateContactPhone() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		service.addContact(contact);
		service.updateContact("56152", 3, "1231231231");
		assertTrue(service.contactList.get(0).getPhone().equals("1231231231"));
	}
	
	// Testing that address was updated
	@Test
	void testContactServiceUpdateContactAddress() {
		Contact contact = new Contact("56152", "Drew", "Test", "5555455545", "123 Test St");		
		ContactService service = new ContactService();
		service.addContact(contact);
		service.updateContact("56152", 4, "321 Test St");
		assertTrue(service.contactList.get(0).getAddress().equals("321 Test St"));
		System.out.println(service.contactList.size());
	}

}
