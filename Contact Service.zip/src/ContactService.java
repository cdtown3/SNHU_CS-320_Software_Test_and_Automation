/*
 * Program: Contact Service JUnit Tests
 * Author: Drew Townsend
 * Date: 05/23/21
 * Desc: Program adds, edits, and deletes contacts to and from a contact list
 */

import java.util.ArrayList;

public class ContactService {
	ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	//Default constructor
	public ContactService() {}
	
	// Adds contact to contactList
	public void addContact(Contact newContact) {
		this.contactList.add(newContact);
	}
	
	// Removes contact based on ID of contact
	public void deleteContact(String contactID) {
		for (int i = 0; i < this.contactList.size(); ++i) {
			if (this.contactList.get(i).getContactID() == contactID) {
				this.contactList.remove(i);
				break;
			}
		}
	}
	
	// Updates contact based on entered parameters
	public void updateContact(String contactID, int toUpdate, String newUpdate) {
		for (int i = 0; i < this.contactList.size(); ++i) {
			if (this.contactList.get(i).getContactID() == contactID) {
				if (toUpdate == 1) {
					this.contactList.get(i).setFirstName(newUpdate);
				} else if (toUpdate == 2) {
					this.contactList.get(i).setLastName(newUpdate);
				} else if (toUpdate == 3) {
					this.contactList.get(i).setPhone(newUpdate);
				} else if (toUpdate == 4) {
					this.contactList.get(i).setAddress(newUpdate);
				}
			}
		}
	}
}
